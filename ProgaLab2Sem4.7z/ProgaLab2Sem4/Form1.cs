﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProgaLab2Sem4
{
    public partial class FormAutorization : Form
    {
        public FormAutorization()
        {
            InitializeComponent();
        }

        private void btnEntry_Click(object sender, EventArgs e)
        {
            string filePath = "C:\\Users\\Анна\\Desktop\\Users.txt";
            FileInfo f = new FileInfo(filePath);

            if (txtBoxUserName.Text == "" || txtBoxPassword.Text == "")
            {
                MessageBox.Show("Не введен логин или пароль");
                return;
            }

            using (StreamReader sr = new StreamReader(f.OpenRead(), Encoding.UTF8))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] splitLine = line.Split(new char[] { ' ' });
                    
                    string name = splitLine[0];
                    string password = splitLine[1];
                    string newFilePath = splitLine[2];

                    if (name == txtBoxUserName.Text && password == txtBoxPassword.Text)
                    {
                        FormAIS formAIS = new FormAIS(newFilePath);
                        formAIS.Show();
                        this.Hide();
                        return;
                    }
                }
                MessageBox.Show("Неверный логин или пароль");
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
